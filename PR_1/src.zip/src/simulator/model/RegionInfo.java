package simulator.model;

public interface RegionInfo extends JSONable {
	// for now it is empty, later we will make it implements the interface
	// Iterable<AnimalInfo>
}
