package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONObject;

import simulator.factories.Factory;

public class Simulator implements JSONable {
	protected Factory<Animal> _animals_factory;
	protected Factory<Region> _regions_factory;
	protected RegionManager _region_mngr;
	protected List<Animal> animals;
	protected double time;

	public Simulator(int cols, int rows, int width, int height, Factory<Animal> animals_factory,
			Factory<Region> regions_factory) {
		this._animals_factory = animals_factory;
		this._regions_factory = regions_factory;
		this._region_mngr = new RegionManager(cols, rows, width, height);
		this.animals = new ArrayList<>();
		time = 0.0;
	}

	private void set_region(int row, int col, Region r) {
		this._region_mngr._regions[row][col] = r;
	}

	public void set_region(int row, int col, JSONObject r_json) {
		Region R = _regions_factory.create_instance(r_json);
		set_region(row, col, R);
	}

	private void add_animal(Animal a) {
		this.animals.add(a);
		_region_mngr.register_animal(a);
	}

	public void add_animal(JSONObject a_json) {
		Animal A = _animals_factory.create_instance(a_json);
		add_animal(A);
	}

	public MapInfo get_map_info() {
		return _region_mngr;
	}

	public List<? extends AnimalInfo> get_animals() {
		return Collections.unmodifiableList(this.animals);
	}

	public double get_time() {
		return this.time;
	}

	public void advance(double dt) {
		this.time += dt;

		List<Animal> deadAnimals = new ArrayList<>();
		for (Animal animal : this.animals) {
			animal.update(dt);
			if (animal.get_state() == State.DEAD) {
				deadAnimals.add(animal);
			}
		}
		for (Animal deadAnimal : deadAnimals) {
			this.animals.remove(deadAnimal);
			this._region_mngr.unregister_animal(deadAnimal);
		}

		_region_mngr.update_all_regions(dt);

		List<Animal> newBabies = new ArrayList<>();
		for (Animal animal : animals) {
			if (animal.is_pregnant()) {
				Animal baby = animal.deliver_baby();
				if (baby != null)
					newBabies.add(baby);
			}
		}
		for (Animal baby : newBabies)
			add_animal(baby);
	}

	public JSONObject as_JSON() {
		JSONObject object = new JSONObject();

		object.put("time", this.time);
		object.put("state", _region_mngr.as_JSON());

		return object;

//		"time": t,
//		"state": s,
	}

}
