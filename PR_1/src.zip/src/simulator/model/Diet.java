package simulator.model;

public enum Diet {
	HERBIVORE, CARNIVORE
}
